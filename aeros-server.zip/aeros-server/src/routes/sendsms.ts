import { Router } from 'express';
import { sendIncidentSMS } from '../controllers/incidentController';

const router = Router();

// Route for sending fallback SMS via Twilio
router.post('/', sendIncidentSMS);

export default router;
