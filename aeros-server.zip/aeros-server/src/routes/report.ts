import { Router } from 'express';
import { reportIncident } from '../controllers/incidentController';
import { validateIncidentRequest } from '../utils/validateRequest';

const router = Router();

// POST /report - Report an emergency incident
router.post('/', validateIncidentRequest, reportIncident);

export default router;
