import { Request, Response } from 'express';
import { classifyIncident } from '../services/openaiService';
import { saveIncident } from '../services/firebaseService';
import { sendSMS } from '../services/twilioService';

// Handle reporting an incident
export const reportIncident = async (req: Request, res: Response) => {
  try {
    const { text, lat, lng } = req.body;
    console.log('Processing incident report:', { text, lat, lng });
    
    // For testing without external APIs, use mock classification
    const classification = { type: 'Test Incident', severity: 'Medium' };
    console.log('Using mock classification:', classification);
    
    // For testing without Firebase, just return success
    const incident = { 
      id: Date.now().toString(),
      text, 
      lat, 
      lng, 
      ...classification,
      timestamp: new Date().toISOString()
    };
    console.log('Incident processed successfully:', incident);
    
    res.status(201).json({ success: true, incident });
  } catch (error) {
    console.error('Error in reportIncident:', error);
    const errMsg = error instanceof Error ? error.message : String(error);
    res.status(500).json({ success: false, error: errMsg });
  }
};

// Handle sending SMS (fallback)
export const sendIncidentSMS = async (req: Request, res: Response) => {
  try {
    const { to, message } = req.body;
    console.log('Sending SMS:', { to, message });
    const result = await sendSMS(to, message);
    console.log('SMS sent successfully:', result);
    res.status(200).json({ success: true, result });
  } catch (error) {
    console.error('Error in sendIncidentSMS:', error);
    const errMsg = error instanceof Error ? error.message : String(error);
    res.status(500).json({ success: false, error: errMsg });
  }
};
