import { Request, Response, NextFunction } from 'express';

// Middleware to validate required fields for incident reporting
export function validateIncidentRequest(req: Request, res: Response, next: NextFunction) {
  const { text, lat, lng } = req.body;
  if (!text || !lat || !lng) {
    return res.status(400).json({ success: false, error: 'Missing required fields: text, lat, lng' });
  }
  next();
}
