import OpenAI from "openai";

// Classify the emergency type and severity using OpenAI
export async function classifyIncident(text: string): Promise<{ type: string; severity: string }> {
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });
  const prompt = `Classify the following emergency report as Accident, Fire, or Medical, and estimate severity (Low, Medium, High):\n"${text}"\nRespond in JSON: {\"type\":\"Accident|Fire|Medical\", \"severity\":\"Low|Medium|High\"}`;
  const response = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages: [
      { role: "system", content: "You are an emergency incident classifier." },
      { role: "user", content: prompt }
    ],
    max_tokens: 60,
    temperature: 0.2,
  });
  try {
    const json = JSON.parse(response.choices[0].message.content || '{}');
    return { type: json.type || 'Unknown', severity: json.severity || 'Unknown' };
  } catch {
    return { type: 'Unknown', severity: 'Unknown' };
  }
}
