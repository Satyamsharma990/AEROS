# AEROS Backend

Node.js + Express backend for the AI-Powered Emergency Response System.

## Setup

1. Create a `.env` file in the root directory with the following variables:
   ```env
   # Server Configuration
   PORT=5000

   # Firebase Configuration
   FIREBASE_PROJECT_ID=your-firebase-project-id
   FIREBASE_CLIENT_EMAIL=your-firebase-client-email
   FIREBASE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nYour Firebase Private Key Here\n-----END PRIVATE KEY-----"

   # OpenAI Configuration
   OPENAI_API_KEY=your-openai-api-key

   # Twilio Configuration
   TWILIO_ACCOUNT_SID=your-twilio-account-sid
   TWILIO_AUTH_TOKEN=your-twilio-auth-token
   TWILIO_PHONE_NUMBER=your-twilio-phone-number
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Run the server (dev mode):
   ```bash
   npx ts-node src/index.ts
   ```

## Environment Variables Setup

### Firebase Setup
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Create a new project or select an existing one
3. Go to Project Settings > Service Accounts
4. Click "Generate new private key"
5. Download the JSON file and extract:
   - `project_id` → `FIREBASE_PROJECT_ID`
   - `client_email` → `FIREBASE_CLIENT_EMAIL`
   - `private_key` → `FIREBASE_PRIVATE_KEY`

### OpenAI Setup
1. Go to [OpenAI API Keys](https://platform.openai.com/api-keys)
2. Create a new API key
3. Add it as `OPENAI_API_KEY`

### Twilio Setup
1. Go to [Twilio Console](https://console.twilio.com/)
2. Get your Account SID and Auth Token
3. Get a phone number for sending SMS
4. Add them as `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_PHONE_NUMBER`

## Endpoints

- `POST /report` — Report an emergency (text, lat, lng)
- `POST /sendsms` — Send fallback SMS via Twilio

## Troubleshooting

If you see "Service account object must contain a string 'project_id' property" error:
1. Make sure your `.env` file exists and contains all required variables
2. Verify that `FIREBASE_PROJECT_ID` is set correctly
3. Check that the Firebase service account JSON was properly parsed
4. Ensure the private key includes the full key with `-----BEGIN PRIVATE KEY-----` and `-----END PRIVATE KEY-----` 