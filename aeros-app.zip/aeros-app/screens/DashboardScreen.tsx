import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: undefined;
  Incident: undefined;
  SOS: undefined;
  Dashboard: undefined;
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'Dashboard'>;

interface Incident {
  id: string;
  type: string;
  location: string;
  lat: number;
  lng: number;
}

const DashboardScreen = () => {
  const navigation = useNavigation<NavigationProp>();
  const [incidents, setIncidents] = useState<Incident[]>([
    {
      id: '1',
      type: 'Traffic Accident',
      location: 'Main Street & 5th Avenue',
      lat: 40.7128,
      lng: -74.0060,
    },
    {
      id: '2',
      type: 'Medical Emergency',
      location: 'Central Park Area',
      lat: 40.7829,
      lng: -73.9654,
    },
    {
      id: '3',
      type: 'Fire Alert',
      location: 'Downtown Business District',
      lat: 40.7589,
      lng: -73.9851,
    },
  ]);

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: 40.7138,
          longitude: -74.0050,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }}
      >
        {incidents.map((incident) => (
          <Marker
            key={incident.id}
            coordinate={{ latitude: incident.lat, longitude: incident.lng }}
            title={incident.type}
            description={incident.location}
          />
        ))}
      </MapView>
      <Text style={styles.sectionTitle}>Current Incidents</Text>
      <ScrollView style={styles.incidentList}>
        {incidents.map((incident) => (
          <TouchableOpacity key={incident.id} style={styles.incidentCard}>
            <Text style={styles.incidentType}>{incident.type}</Text>
            <Text style={styles.incidentLocation}>{incident.location}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
      <TouchableOpacity style={styles.viewAllButton}>
        <Text style={styles.viewAllText}>VIEW ALL</Text>
      </TouchableOpacity>
      
      {/* Navigation Buttons */}
      <View style={styles.navigationContainer}>
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.navButtonText}>🏠 Home</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Incident')}
        >
          <Text style={styles.navButtonText}>📋 Incident</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('SOS')}
        >
          <Text style={styles.navButtonText}>🚨 SOS</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDF6F2',
    paddingTop: 48,
    paddingHorizontal: 0,
  },
  map: {
    width: Dimensions.get('window').width,
    height: 180,
    borderRadius: 16,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 12,
    marginLeft: 16,
  },
  incidentList: {
    flex: 1,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  incidentCard: {
    backgroundColor: '#FF6B6B',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
  },
  incidentType: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  incidentLocation: {
    color: '#fff',
    fontSize: 14,
    marginTop: 4,
  },
  viewAllButton: {
    alignSelf: 'center',
    marginTop: 8,
    marginBottom: 16,
  },
  viewAllText: {
    color: '#FF6B6B',
    fontWeight: 'bold',
    fontSize: 14,
    letterSpacing: 1,
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
    paddingHorizontal: 20,
  },
  navButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
    minWidth: 80,
  },
  navButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
});

export default DashboardScreen; 