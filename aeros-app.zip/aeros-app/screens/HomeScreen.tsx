import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, ActivityIndicator, Alert } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: undefined;
  Incident: undefined;
  SOS: undefined;
  Dashboard: undefined;
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'Home'>;
import * as Location from 'expo-location';
import { reportIncident } from '../services/api';

const HomeScreen = () => {
  const navigation = useNavigation<NavigationProp>();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);

  const handleReport = async () => {
    setLoading(true);
    try {
      // Get location
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission denied', 'Location permission is required.');
        setLoading(false);
        return;
      }
      let location = await Location.getCurrentPositionAsync({});
      const lat = location.coords.latitude;
      const lng = location.coords.longitude;
      // Call backend
      await reportIncident({ text, lat, lng });
      setLoading(false);
      Alert.alert('Reported!', 'Your emergency has been reported.');
      setText('');
      // Navigate to IncidentScreen to show the reported incident
      navigation.navigate('Incident');
    } catch (err: any) {
      setLoading(false);
      Alert.alert('Error', err.message || 'Failed to report incident.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>AI-Powered{"\n"}Emergency Response</Text>
      <Text style={styles.subtitle}>Describe the emergency</Text>
      <TextInput
        style={styles.input}
        placeholder="Type or speak your emergency..."
        value={text}
        onChangeText={setText}
        multiline
      />
      <TouchableOpacity style={styles.micButton}>
        <MaterialCommunityIcons name="microphone" size={64} color="#FF6B6B" />
      </TouchableOpacity>
      <TouchableOpacity style={styles.reportButton} onPress={handleReport} disabled={loading || !text}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.reportButtonText}>REPORT INCIDENT</Text>}
      </TouchableOpacity>
      <View style={styles.emergencyTypes}>
        <TouchableOpacity style={styles.typeButton}>
          <FontAwesome5 name="car-crash" size={24} color="#FF6B6B" />
          <Text style={styles.typeText}>Accident</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.typeButton}>
          <MaterialCommunityIcons name="fire" size={24} color="#FF6B6B" />
          <Text style={styles.typeText}>Fire</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.typeButton}>
          <FontAwesome5 name="first-aid" size={24} color="#FF6B6B" />
          <Text style={styles.typeText}>Medical</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.contactsLink}>
        <Text style={styles.contactsText}>EMERGENCY CONTACTS</Text>
      </TouchableOpacity>
      
      {/* Navigation Buttons */}
      <View style={styles.navigationContainer}>
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Dashboard')}
        >
          <Text style={styles.navButtonText}>📊 Dashboard</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('SOS')}
        >
          <Text style={styles.navButtonText}>🚨 SOS</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Incident')}
        >
          <Text style={styles.navButtonText}>📋 Incident</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDF6F2',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    color: '#222',
  },
  subtitle: {
    fontSize: 16,
    color: '#888',
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    width: '100%',
    minHeight: 60,
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 12,
    fontSize: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#FF6B6B',
  },
  micButton: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#FFF0F0',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#FF6B6B',
  },
  reportButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 32,
    paddingVertical: 16,
    paddingHorizontal: 40,
    marginBottom: 32,
    minWidth: 200,
    alignItems: 'center',
  },
  reportButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18,
    letterSpacing: 1,
  },
  emergencyTypes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 24,
  },
  typeButton: {
    alignItems: 'center',
    marginHorizontal: 12,
  },
  typeText: {
    marginTop: 4,
    color: '#FF6B6B',
    fontWeight: 'bold',
  },
  contactsLink: {
    marginTop: 12,
  },
  contactsText: {
    color: '#FF6B6B',
    fontWeight: 'bold',
    fontSize: 14,
    letterSpacing: 1,
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
    paddingHorizontal: 20,
  },
  navButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
    minWidth: 80,
  },
  navButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
});

export default HomeScreen; 