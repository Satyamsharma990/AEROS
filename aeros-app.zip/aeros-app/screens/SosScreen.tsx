import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import { sendSOS } from '../services/api';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: undefined;
  Incident: undefined;
  SOS: undefined;
  Dashboard: undefined;
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'SOS'>;

const SOS_PHONE = '+1234567890'; // Replace with real fallback number

const SosScreen = () => {
  const navigation = useNavigation<NavigationProp>();
  const [loading, setLoading] = useState(false);

  const handleSOS = async () => {
    setLoading(true);
    const netState = await NetInfo.fetch();
    if (!netState.isConnected) {
      // Offline fallback: send SMS via Twilio (backend)
      try {
        await sendSOS({ to: SOS_PHONE, message: 'Distress signal sent from AEROS app (offline mode).' });
        setLoading(false);
        Alert.alert('SOS Sent', 'Distress signal sent via SMS.');
      } catch (err: any) {
        setLoading(false);
        Alert.alert('Error', err.message || 'Failed to send SOS.');
      }
      return;
    }
    // Online: could trigger a real-time alert (not implemented here)
    setLoading(false);
    Alert.alert('SOS Sent', 'Distress signal sent online.');
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.sosButton}
        onLongPress={handleSOS}
        disabled={loading}
      >
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.sosText}>SOS</Text>}
      </TouchableOpacity>
      <Text style={styles.sosHint}>Press and hold to send a distress signal</Text>
      <Text style={styles.offlineMode}>OFFLINE MODE</Text>
      
      {/* Navigation Buttons */}
      <View style={styles.navigationContainer}>
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.navButtonText}>🏠 Home</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Incident')}
        >
          <Text style={styles.navButtonText}>📋 Incident</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Dashboard')}
        >
          <Text style={styles.navButtonText}>📊 Dashboard</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDF6F2',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sosButton: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#FF6B6B',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  sosText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 36,
    letterSpacing: 2,
  },
  sosHint: {
    color: '#888',
    fontSize: 16,
    marginBottom: 8,
  },
  offlineMode: {
    color: '#FF6B6B',
    fontWeight: 'bold',
    fontSize: 14,
    letterSpacing: 1,
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
    paddingHorizontal: 20,
  },
  navButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
    minWidth: 80,
  },
  navButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
});

export default SosScreen; 