import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: undefined;
  Incident: undefined;
  SOS: undefined;
  Dashboard: undefined;
};

type NavigationProp = NativeStackNavigationProp<RootStackParamList, 'Incident'>;

const incident = {
  type: 'Traffic Accident',
  status: 'Help is on the way',
  eta: 'Ambulance ~ ETA: 4 min',
  lat: 40.7128,
  lng: -74.0060,
};

const IncidentScreen = () => {
  const navigation = useNavigation<NavigationProp>();
  
  return (
    <View style={styles.container}>
      <View style={styles.incidentTypeBox}>
        <Text style={styles.incidentTypeText}>🚗 {incident.type}</Text>
      </View>
      <Text style={styles.statusText}>{incident.status}</Text>
      <Text style={styles.etaText}>{incident.eta}</Text>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: incident.lat,
          longitude: incident.lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }}
      >
        <Marker
          coordinate={{ latitude: incident.lat, longitude: incident.lng }}
          title={incident.type}
          description={incident.status}
        />
      </MapView>
      <TouchableOpacity style={styles.updatesButton}>
        <Text style={styles.updatesButtonText}>VIEW UPDATES</Text>
      </TouchableOpacity>
      <View style={styles.sosContainer}>
        <TouchableOpacity style={styles.sosButton}>
          <Text style={styles.sosText}>SOS</Text>
        </TouchableOpacity>
        <Text style={styles.sosHint}>Press and hold to send a distress signal</Text>
        <Text style={styles.offlineMode}>OFFLINE MODE</Text>
      </View>
      
      {/* Navigation Buttons */}
      <View style={styles.navigationContainer}>
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Home')}
        >
          <Text style={styles.navButtonText}>🏠 Home</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('Dashboard')}
        >
          <Text style={styles.navButtonText}>📊 Dashboard</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.navButton} 
          onPress={() => navigation.navigate('SOS')}
        >
          <Text style={styles.navButtonText}>🚨 SOS</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FDF6F2',
    alignItems: 'center',
    paddingTop: 60,
  },
  incidentTypeBox: {
    backgroundColor: '#FF6B6B',
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 24,
    marginBottom: 24,
  },
  incidentTypeText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18,
  },
  statusText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 8,
  },
  etaText: {
    fontSize: 16,
    color: '#888',
    marginBottom: 24,
  },
  map: {
    width: Dimensions.get('window').width - 32,
    height: 160,
    borderRadius: 16,
    marginBottom: 24,
  },
  updatesButton: {
    backgroundColor: '#fff',
    borderRadius: 24,
    borderWidth: 2,
    borderColor: '#FF6B6B',
    paddingVertical: 10,
    paddingHorizontal: 32,
    marginBottom: 32,
  },
  updatesButtonText: {
    color: '#FF6B6B',
    fontWeight: 'bold',
    fontSize: 16,
  },
  sosContainer: {
    alignItems: 'center',
    marginTop: 24,
  },
  sosButton: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#FF6B6B',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  sosText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 32,
    letterSpacing: 2,
  },
  sosHint: {
    color: '#888',
    fontSize: 14,
    marginBottom: 4,
  },
  offlineMode: {
    color: '#FF6B6B',
    fontWeight: 'bold',
    fontSize: 12,
    letterSpacing: 1,
  },
  navigationContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    marginTop: 20,
    paddingHorizontal: 20,
  },
  navButton: {
    backgroundColor: '#FF6B6B',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 16,
    alignItems: 'center',
    minWidth: 80,
  },
  navButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 12,
  },
});

export default IncidentScreen; 