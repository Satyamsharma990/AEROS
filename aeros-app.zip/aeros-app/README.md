# AEROS Mobile App (Expo)

AI-Powered Emergency Response System

## Features
- Report emergencies via text or voice
- AI classifies emergency type and severity
- Real-time incident dashboard (Firestore)
- Google Maps for incident locations
- SOS button with offline SMS fallback (Twilio)

## Setup

1. **Clone the repo and install dependencies:**
   ```sh
   npm install
   ```

2. **Create a `.env` file in `aeros-app/` with your Firebase and backend API config:**
   ```env
   EXPO_PUBLIC_FIREBASE_API_KEY=your-firebase-api-key
   EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN=your-firebase-auth-domain
   EXPO_PUBLIC_FIREBASE_PROJECT_ID=your-firebase-project-id
   EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET=your-firebase-storage-bucket
   EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your-firebase-messaging-sender-id
   EXPO_PUBLIC_FIREBASE_APP_ID=your-firebase-app-id
   EXPO_PUBLIC_API_URL=http://localhost:5000
   ```

3. **Start the Expo app:**
   ```sh
   npm start
   ```
   - Use Expo Go app or an emulator to preview.

4. **Configure Google Maps:**
   - For iOS/Android, follow [react-native-maps setup](https://docs.expo.dev/versions/latest/sdk/map-view/).

## Folder Structure
- `/screens` — Main app screens
- `/components` — Reusable UI components
- `/services` — API and Firebase logic
- `/assets` — App icons/images

## Environment Variables
See `.env.example` for all required variables.

---

**Backend:** See `aeros-server/README.md` for backend setup. 