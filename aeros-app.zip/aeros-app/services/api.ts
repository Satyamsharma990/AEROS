import axios from 'axios';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:5000';

export const reportIncident = async (data: { text: string; lat: number; lng: number }) => {
  return axios.post(`${API_URL}/report`, data);
};

export const sendSOS = async (data: { to: string; message: string }) => {
  return axios.post(`${API_URL}/sendsms`, data);
}; 